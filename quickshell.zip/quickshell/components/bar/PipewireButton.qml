import QtQuick
import QtQuick.Layouts
import QtQuick.Controls
import Quickshell.Wayland
import "../../config/theme.js" as Theme
import "../windows/pipewire" as Pipewire

Item {
    id: root
    Layout.preferredWidth: parent.width / 3
    Layout.preferredHeight: 30

    Pipewire.Window {
        id: pipewireWindow
        visible: root.menuOpen
    }

    property bool menuOpen: false

    Rectangle {
        anchors.fill: parent
        radius: height / 2
        color: Theme.bgItem
        border.width: 0
        opacity: mouseArea.containsMouse ? 0.9 : 1.0
        Behavior on opacity {
            NumberAnimation {
                duration: 120
            }
        }
    }

    MouseArea {
        id: mouseArea
        anchors.fill: parent
        cursorShape: Qt.PointingHandCursor
        onClicked: {
            mouse.accepted = true;
            root.menuOpen = !root.menuOpen;
        }
    }

    RowLayout {
        anchors.centerIn: parent
        spacing: 6
        Layout.preferredWidth: 60
        Text {
            text: ""
            color: Theme.textPrimary
        }
        Text {
            text: "20%"
            color: Theme.textPrimary
        }
    }
}
