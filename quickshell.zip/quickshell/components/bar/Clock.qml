import QtQuick
import QtQuick.Layouts
import Qt5Compat.GraphicalEffects
import "../../config/theme.js" as Theme
import "../windows/calendar" as Calendar

Rectangle {
    id: root

    property bool isDarkMode: true
    signal clicked
    Layout.preferredHeight: 30
    Layout.preferredWidth: clockRow.implicitWidth + 30
    radius: 20
    color: palette.bg
    clip: true

    Calendar.Window {
        id: calendarWindow
        visible: false
    }

    QtObject {
        id: palette
        property color bg: Theme.bg
        property color textPrimary: Theme.textPrimary
        property color textSecondary: Theme.textSecondary
        property color accent: Theme.accent
    }

    RowLayout {
        id: clockRow
        anchors.centerIn: parent
        spacing: 8
        Text {
            id: dateText
            text: Qt.formatDateTime(new Date(), "ddd, MMM d")
            font.family: Theme.textFont
            font.pixelSize: 12
            font.weight: 600
            color: palette.accent
        }
        Text {
            text: "•"
            font.pixelSize: 10
            color: palette.textSecondary
        }
        Text {
            id: timeText
            text: Qt.formatDateTime(new Date(), "hh:mm:ss AP")
            font.family: Theme.textFont
            font.pixelSize: 13
            font.weight: 800
            color: palette.textPrimary
        }
        Timer {
            interval: 1000
            running: true
            repeat: true
            onTriggered: {
                var now = new Date();
                dateText.text = Qt.formatDateTime(now, "ddd, MMM d");
                timeText.text = Qt.formatDateTime(now, "hh:mm:ss AP");
            }
        }
    }

    Rectangle {
        id: clockMask
        anchors.fill: parent
        radius: 17
        visible: false
    }

    Item {
        anchors.fill: parent
        layer.enabled: true
        layer.smooth: true
        layer.effect: OpacityMask {
            maskSource: clockMask
        }
        Rectangle {
            id: clockShimmer
            width: 44
            height: parent.height * 2
            rotation: 20
            x: -100
            y: -parent.height / 2
            color: "transparent"
        }
    }

    NumberAnimation {
        id: clockShimmerAnim
        target: clockShimmer
        property: "x"
        from: -60
        to: root.width + 60
        duration: 800
        easing.type: Easing.InOutQuad
    }


    Rectangle {
        anchors.fill: parent
        radius: 17
        color: "transparent"
        border.width: 0
    }

    MouseArea {
        anchors.fill: parent
        onClicked: function(mouse) {
            mouse.accepted = true;
            root.clicked();
            calendarWindow.visible = !calendarWindow.visible;
        }
        cursorShape: Qt.PointingHandCursor
        preventStealing: true
        propagateComposedEvents: false
    }
}
