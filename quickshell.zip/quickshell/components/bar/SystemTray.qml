import QtQuick
import Quickshell.Services.SystemTray

Rectangle {
    id: root

    property bool isDarkMode: true

    visible: SystemTray.items.length > 0
    height: 30
    width: (SystemTray.items.length * 28) + 12
    radius: 15
    color: palette.bg
    border.width: 1
    border.color: palette.border

    QtObject {
        id: palette
        property color bg: root.isDarkMode ? Qt.rgba(0.15, 0.15, 0.15) : '#edc5c6b0'
        property color border: root.isDarkMode ? Qt.rgba(1, 1, 1, 0.08) : Qt.rgba(0, 0, 0, 0.1)
        property color hoverSpotlight: root.isDarkMode ? Qt.rgba(1, 1, 1, 0.14) : Qt.rgba(0, 0, 0, 0.10)
    }

    Row {
        anchors.centerIn: parent
        spacing: 8
        Repeater {
            model: SystemTray.items
            Item {
                width: 20
                height: 20
                scale: trayPress.pressed ? 0.94 : (trayPress.containsMouse ? 1.06 : 1.0)
                Behavior on scale {
                    NumberAnimation {
                        duration: 200
                        easing.type: Easing.OutBack
                        easing.overshoot: 1.08
                    }
                }

                Rectangle {
                    anchors.fill: parent
                    radius: width / 2
                    color: root.isDarkMode ? Qt.rgba(1, 1, 1, 0.14) : Qt.rgba(0, 0, 0, 0.10)
                    opacity: trayPress.pressed ? 1.0 : (trayPress.containsMouse ? 0.8 : 0.0)
                    Behavior on opacity {
                        NumberAnimation {
                            duration: 120
                            easing.type: Easing.OutCubic
                        }
                    }
                }

                Image {
                    anchors.centerIn: parent
                    width: 16
                    height: 16
                    source: {
                        var icon = modelData.icon || "";
                        // Strip query parameters from icon paths (e.g., "spotify-linux-32?path=/opt/spotify/icons")
                        var qIndex = icon.indexOf("?");
                        return (qIndex >= 0) ? icon.substring(0, qIndex) : icon;
                    }
                    visible: status === Image.Ready
                }

                MouseArea {
                    id: trayPress
                    anchors.fill: parent
                    hoverEnabled: true
                    acceptedButtons: Qt.LeftButton | Qt.RightButton
                    onClicked: mouse => modelData.activate(mouse.button)
                    onPressed: mouse => {
                        if (mouse.button === Qt.RightButton)
                            modelData.menu.open(this);
                    }
                }
            }
        }
    }
}
