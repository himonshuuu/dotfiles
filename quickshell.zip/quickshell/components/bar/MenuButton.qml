import QtQuick
import QtQuick.Layouts

import "../../config/theme.js" as Theme
import "../windows/hub" as Hub
Item {
    id: root
    signal clicked

    implicitWidth: layout.implicitWidth + 16
    implicitHeight: 30

    Hub.Window {
        id: hubWindow
        visible: false
    }

    Rectangle {
        anchors.fill: parent
        color: Theme.bgItem
        radius: height / 2
        border.width: 1
        border.color: Theme.border
        opacity: hover.hovered ? 0.9 : 1.0
        Behavior on opacity {
            NumberAnimation { duration: 120 }
        }
    }

    RowLayout {
        id: layout
        anchors.centerIn: parent
        spacing: 0
        Text {
            text: "󰣇"
            font.family: Theme.iconFont
            font.pixelSize: 18
            color: Theme.textPrimary
        }
    }

    MouseArea {
        anchors.fill: parent
        onClicked: {
            root.clicked()
            hubWindow.visible = !hubWindow.visible
        }
    }

    HoverHandler {
        id: hover
    }
}