import QtQuick
import QtQuick.Layouts
import QtQuick.Controls
import Qt5Compat.GraphicalEffects
import Quickshell
import Quickshell.Io
import Quickshell.Wayland
import Quickshell.Services.SystemTray
import Quickshell.Services.Mpris
import Quickshell.Hyprland
import QtQuick.Shapes

import "../../config/theme.js" as Theme
import "../ui" as Lib
import "../../utils" as Utils
import "../../services" as Services
import "."


PanelWindow {
    id: win

    signal requestHubToggle
    signal requestPowerMenu
    signal requestMenu

    anchors {
        top: true
        left: true
        right: true
    }
    implicitHeight: 42
    color: "transparent"

    property bool isDarkMode: true

    WlrLayershell.layer: WlrLayer.Top
    WlrLayershell.exclusiveZone: 33
    WlrLayershell.namespace: "shell-bar"

    Utils.CommandUtils {
        id: cmdUtils
    }

    property int activeWsId: Hyprland.focusedMonitor?.activeWorkspace?.id ?? 1

    HyprlandCache {
        id: hyCache
    }

    Services.BatteryService {
        id: batteryService
    }

    Rectangle {
        anchors.fill: parent
        anchors.margins: 2
        anchors.leftMargin: 10
        anchors.rightMargin: 10
        color: "transparent"

        RowLayout {
            anchors.fill: parent
            spacing: 10

            RowLayout {
                spacing: 10
                Layout.alignment: Qt.AlignLeft
                Layout.fillWidth: false
                Layout.preferredWidth: implicitWidth

                MenuButton {
                    onClicked: win.requestHubToggle()
                }

                WorkspacesContainer {
                    id: workspaces
                    activeWsId: win.activeWsId
                    wsMap: hyCache.wsMap
                    onWorkspaceClicked: wsId => cmdUtils.det("hyprctl dispatch workspace " + wsId)
                }

                SystemTray {}
            }

            Item {
                Layout.fillWidth: true
                Layout.minimumWidth: 0
                Layout.preferredWidth: 0
            }
            
            RowLayout {
                spacing: 10
                Layout.alignment: Qt.AlignHCenter
                Layout.fillWidth: false
                Layout.preferredWidth: implicitWidth

                MediaTitle {}
                Clock {}
            }

            Item {
                Layout.fillWidth: true
                Layout.minimumWidth: 0
                Layout.preferredWidth: 0
            }

            RowLayout {
                spacing: 10
                Layout.alignment: Qt.AlignRight
                Layout.fillWidth: false
                Layout.preferredWidth: implicitWidth

                WifiButton {}
                PipewireButton {}

                BatteryIndicator {
                    status: batteryService.status
                    rawCap: batteryService.capacity
                    plugged: batteryService.plugged
                }
            }
        }
    }
}
