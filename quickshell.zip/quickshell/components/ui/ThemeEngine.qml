import QtQuick
import "../../config/theme.js" as Theme // Dark-mode

QtObject {
    id: root
    // 1) Surfaces
    readonly property color bgMain: "#141719"

    // Card + item surfaces
    readonly property color bgCard: Theme.bgCard
    readonly property color bgItem: Theme.bgItem
    readonly property color bgWidget: Theme.bgItem

    // 2) Text
    readonly property color textPrimary: Theme.fgMain
    readonly property color textSecondary: Theme.fgMuted
    readonly property color textOnAccent: Theme.fgOnAccent

    // 3) Accents
    readonly property color accent: Theme.accent
    readonly property color accentSlider: "#83C092"

    // 4) Lines, hovers, misc
    readonly property color border: "#70a7c080"

    // General outlines used by small controls (avatar ring, tiny pills, etc.)
    readonly property color outline: "#70a7c080"

    // Subtle fills for small buttons
    readonly property color subtleFill: "#70a7c080"
    readonly property color subtleFillHover: "#70a7c080"
    readonly property color accentRed: Theme.accentRed

    // Hover spotlight
    readonly property color hoverSpotlight: "#70a7c080"
}
