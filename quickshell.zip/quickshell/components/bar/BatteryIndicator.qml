import QtQuick
import QtQuick.Layouts
import "../../config/theme.js" as Theme

Item {
    id: root

    property string status: ""
    property int rawCap: 0
    property int cap: (rawCap === 0 && status !== "Discharging") ? 50 : rawCap
    property bool plugged: false
    property bool isCharging: plugged || status === "Charging" || status === "Full"

    Layout.preferredWidth: 72
    Layout.preferredHeight: 30
    implicitWidth: layout.implicitWidth + 16
    implicitHeight: 30

    QtObject {
        id: palette
        property color bg: Theme.bg
        property color textPrimary: Theme.textPrimary
        property color accent: Theme.accent
    }

    property string battColor: {
        if (isCharging)
            return palette.accent;
        const crit = '#ff0004';
        const low = '#ff001e';
        const mid = '#e69875';
        if (cap <= 10)
            return crit;
        if (cap <= 20)
            return low;
        if (cap <= 30)
            return mid;
        return palette.textPrimary;
    }

    property string dynamicIcon: {
        if (isCharging)
            return "󰂄";
        if (cap >= 98)
            return "󰁹";
        if (cap >= 90)
            return "󰂂";
        if (cap >= 80)
            return "󰂁";
        if (cap >= 70)
            return "󰂀";
        if (cap >= 60)
            return "󰁿";
        if (cap >= 50)
            return "󰁾";
        if (cap >= 40)
            return "󰁽";
        if (cap >= 30)
            return "󰁼";
        if (cap >= 20)
            return "󰁻";
        return "󰁺";
    }

    Rectangle {
        anchors.fill: parent
        radius: height / 2
        color: palette.bg
        border.width: 0
        opacity: hover.hovered ? 0.9 : 1.0
        Behavior on opacity {
            NumberAnimation { duration: 120 }
        }
    }

    RowLayout {
        id: layout
        anchors.centerIn: parent
        spacing: 6
        Text {
            text: root.dynamicIcon
            font.family: Theme.iconFont
            font.pixelSize: 14
            color: root.battColor
        }
        Text {
            text: root.cap + "%"
            font.family: Theme.textFont
            font.pixelSize: 13
            font.weight: 700
            color: root.battColor
        }
    }

    SequentialAnimation {
        running: cap <= 10 && !isCharging
        loops: Animation.Infinite
        NumberAnimation {
            target: root
            property: "opacity"
            to: 0.3
            duration: 500
        }
        NumberAnimation {
            target: root
            property: "opacity"
            to: 1.0
            duration: 500
        }
    }

    Rectangle {
        id: powerSurge
        anchors.centerIn: parent
        width: parent.width
        height: 30
        radius: 1
        color: "transparent"
        border.width: 0
        border.color: "transparent"
        opacity: 0
        scale: 1.0
    }

    onPluggedChanged: if (plugged)
        surgeAnim.restart()

    ParallelAnimation {
        id: surgeAnim
        NumberAnimation {
            target: powerSurge
            property: "scale"
            from: 1.0
            to: 1.45
            duration: 520
            easing.type: Easing.OutCubic
        }
        NumberAnimation {
            target: powerSurge
            property: "opacity"
            from: 1.0
            to: 0.0
            duration: 520
            easing.type: Easing.OutCubic
        }
    }

    HoverHandler {
        id: hover
    }
}
