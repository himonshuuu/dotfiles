import QtQuick
import QtQuick.Layouts
import "../../../config/theme.js" as Theme

Rectangle {
    required property string ssid
    required property string uuid
    required property string name
    required property bool isBusy
    required property color accent
    required property color accentBlue
    required property color textPrimary
    required property color textSecondary
    
    signal connectRequested(string uuid, string ssid)
    
    width: ListView.view ? ListView.view.width : 0
    height: 35
    radius: 12
    color: sm.containsMouse ? Qt.rgba(accentBlue.r, accentBlue.g, accentBlue.b, 0.10) : "transparent"
    opacity: isBusy ? 0.6 : 1.0

    RowLayout {
        anchors.fill: parent
        anchors.margins: 10
        spacing: 10
        Text { text: "󰤨"; font.family: Theme.iconFont; font.pixelSize: 14; color: accent }
        Text {
            text: name || ssid || ""
            color: textPrimary
            font.family: Theme.textFont
            font.pixelSize: 13
            font.weight: Font.Bold
            Layout.fillWidth: true
            elide: Text.ElideRight
        }
        Text { text: "Saved"; color: textSecondary; font.family: Theme.textFont; font.pixelSize: 10 }
    }

    MouseArea {
        id: sm
        anchors.fill: parent
        hoverEnabled: true
        cursorShape: isBusy ? Qt.ArrowCursor : Qt.PointingHandCursor
        enabled: !isBusy
        onClicked: connectRequested(uuid, ssid)
    }
}

