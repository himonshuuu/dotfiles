import QtQuick
import Quickshell
import Quickshell.Wayland
import Quickshell.Io
import Quickshell.Hyprland
import "components/bar" as Bar

ShellRoot {
    Variants {
        model: Quickshell.screens

        Scope {
            id: v
            property var modelData

            Bar.Bar {
                id: bar
                screen: v.modelData
            }
        }
    }
}
