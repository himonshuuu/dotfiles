.pragma library

var bgPanel      = "#282828" // dark grey
var bgCard       = "#32302f" // slightly lighter bg
var bgItem       = "#3c3836" // raised item bg
var bgItemHover  = "#504945" // hover item bg
var bg           = "#282828" // main bg
var border       = "#665c54" // neutral border
var fgMain       = "#ebdbb2" // main text
var fgMuted      = "#a89984" // muted text
var fgOnAccent   = "#282828" // text on accent

var accent       = "#b8bb26" // bright green
var accentBlue   = "#83a598" // soft blue
var accentRed    = "#fb4934" // strong red
var weatherd     = "#fbf1c7" // light yellow (day)
var weatherl     = "#7c6f64" // brown/grey (low)

var textPrimary    = "#ebdbb2" // main text
var textSecondary  = "#bdae93" // secondary text

// Sizing
var radiusOuter = 24
var radiusInner = 16

var btnH = 54
var sliderH = 24
var gapCard = 12  // Spacing between cards in layouts

// Fonts
var textFont = 'JetBrains Mono'
var iconFont = 'JetBrainsMono Nerd Font'
