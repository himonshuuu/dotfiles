import QtQuick
import QtQuick.Layouts
import Quickshell
import "../../ui" as Lib
import "../../widgets" as Widgets
import "../../../config/theme.js" as Theme
import "../../../utils" as Utils

Lib.Card {
    id: root

    pad: 12
    gap: 8

    signal closeRequested
    property bool active: true

    Utils.CommandUtils {
        id: cmdUtils
    }

    property bool muteMic: false
    property bool muteSpk: false
    property int micVolume: 0
    property int spkVolume: 0

    function toggleMic() {
        muteMic = !muteMic;
        cmdUtils.det("pactl set-source-mute @DEFAULT_SOURCE@ " + (muteMic ? "true" : "false"));
    }

    function toggleSpk() {
        muteSpk = !muteSpk;
        cmdUtils.det("pactl set-sink-mute @DEFAULT_SINK@ " + (muteSpk ? "true" : "false"));
    }

    Widgets.CommandPoll {
        id: micPoll
        running: root.active && root.visible
        interval: 1000
        command: cmdUtils.sh("pactl get-source-mute @DEFAULT_SOURCE@")
        parse: function (o) {
            return o === "true";
        }
        onUpdated: {
            root.muteMic = value;
        }
    }

    Widgets.CommandPoll {
        id: spkPoll
        running: root.active && root.visible
        interval: 1000
        command: cmdUtils.sh("pactl get-sink-mute @DEFAULT_SINK@")
        parse: function (o) {
            return o === "true";
        }
        onUpdated: {
            root.muteSpk = value;
        }
    }

    Widgets.CommandPoll {
        id: micVolPoll
        running: root.active && root.visible
        interval: 1200
        command: cmdUtils.sh("pactl get-source-volume @DEFAULT_SOURCE@ 2>/dev/null | grep -Po '\\d+(?=%)' | head -n1")
        parse: function (o) {
            var n = parseInt(String(o).trim());
            return isFinite(n) ? n : 0;
        }
        onUpdated: {
            if (!micSlider.pressed) micSlider.value = value;
        }
    }

    Widgets.CommandPoll {
        id: spkVolPoll
        running: root.active && root.visible
        interval: 1200
        command: cmdUtils.sh("pactl get-sink-volume @DEFAULT_SINK@ 2>/dev/null | grep -Po '\\d+(?=%)' | head -n1")
        parse: function (o) {
            var n = parseInt(String(o).trim());
            return isFinite(n) ? n : 0;
        }
        onUpdated: {
            if (!spkSlider.pressed) spkSlider.value = value;
        }
    }

    ColumnLayout {
        spacing: 12
        width: parent.width

        RowLayout {
            spacing: 12
            Layout.fillWidth: true

            Widgets.ExpressiveButton {
                theme: root.theme
                icon: root.muteMic ? "" : ""
                label: root.muteMic ? "Unmute Mic" : "Mute Mic"
                active: root.muteMic
                onClicked: toggleMic()
                fixX: -3
            }
            Widgets.ExpressiveButton {
                theme: root.theme
                icon: root.muteSpk ? "󰕾" : ""
                label: root.muteSpk ? "Unmute Spk" : "Mute Spk"
                active: root.muteSpk
                onClicked: toggleSpk()
                fixX: -3
            }
        }

        ColumnLayout {
            spacing: 8
            Layout.fillWidth: true

            Widgets.ExpressiveSlider {
                id: micSlider
                theme: root.theme
                icon: ""
                from: 0
                to: 100
                value: 0
                Layout.fillWidth: true
                accentColor: "#83C092"
                onUserChanged: cmdUtils.det("pactl set-source-volume @DEFAULT_SOURCE@ " + Math.round(value) + "%")
            }

            Widgets.ExpressiveSlider {
                id: spkSlider
                theme: root.theme
                icon: "󰕾"
                from: 0
                to: 100
                value: 0
                Layout.fillWidth: true
                accentColor: "#83C092"
                onUserChanged: cmdUtils.det("pactl set-sink-volume @DEFAULT_SINK@ " + Math.round(value) + "%")
            }
        }
    }
}
