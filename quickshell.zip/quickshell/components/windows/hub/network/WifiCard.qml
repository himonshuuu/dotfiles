import QtQuick
import QtQuick.Layouts
import QtQuick.Controls
import Qt5Compat.GraphicalEffects
import Quickshell
import Quickshell.Io
import "../../../ui" as Lib
import "../../../../config/theme.js" as Theme

Lib.Card {
    id: root
    Layout.fillWidth: true

    property bool active: false
    property QtObject theme: null

    readonly property color textPrimary: Theme.fgMain
    readonly property color textSecondary: Theme.fgMuted
    readonly property color accent: Theme.accent
    readonly property color accentRed: Theme.accentRed
    readonly property color accentBlue: Theme.accentBlue
    readonly property color bgItem: Theme.bgItem
    readonly property color bgItemHover: Theme.bgItemHover

    property real contentHeight: contentLayout.implicitHeight + (root.pad * 2)

    // smooth expand/collapse animation based on active state
    implicitHeight: root.active ? contentHeight : 0
    opacity: root.active ? 1.0 : 0.0
    visible: implicitHeight > 1
    clip: true

    // Regular hover/Spotlight background effect
    Rectangle {
        parent: root
        anchors.fill: parent
        radius: root.radius
        color: root.theme ? root.theme.hoverSpotlight : Qt.rgba(1, 1, 1, 0.08)
        opacity: root.active ? 0.18 : 0
        z: 0
    }

    readonly property int statusRefreshInterval: 5000
    readonly property int processTimeout: 20000
    readonly property int scanDebounceDelay: 500

    property bool isExpanded: false
    property bool isBusy: false
    property bool scanRunning: false

    property bool wifiEnabled: true
    property bool isWired: false
    property string activeConnectionUuid: ""
    property string currentSsid: "Checking…"
    property int currentSignalVal: 0
    property string currentIp: ""

    property string statusLine: ""
    property color statusColor: Theme.fgMuted

    property string targetSsid: ""
    property bool targetIsEnterprise: false
    property string enteredUser: ""
    property string enteredPass: ""

    property string pendingSavedUuid: ""
    property string pendingSavedSsid: ""

    Timer {
        id: statusTimer
        interval: 3200
        repeat: false
        onTriggered: statusLine = ""
    }

    Timer {
        id: processWatchdog
        interval: processTimeout
        repeat: false
        onTriggered: {
            if (isBusy || scanRunning) {
                setStatus("Operation timed out - please wait", true)
            }
        }
    }

    Timer {
        id: scanDebounce
        interval: scanDebounceDelay
        repeat: false
        onTriggered: performScan()
    }

    Timer {
        interval: statusRefreshInterval
        repeat: true
        running: root.active && root.visible
        triggeredOnStart: false
        onTriggered: {
            if (!isBusy && !scanRunning) {
                refreshStatus()
            }
        }
    }

    function setStatus(msg, bad) {
        statusLine = msg
        statusColor = bad ? Theme.accentRed : Theme.fgMuted
        statusTimer.restart()
    }

    function shellQuote(s) {
        return "'" + String(s).replace(/'/g, "'\\''") + "'"
    }

    function getSignalIcon(strength) {
        if (strength > 80) return "󰤨"
        if (strength > 60) return "󰤥"
        if (strength > 40) return "󰤢"
        if (strength > 20) return "󰤟"
        return "󰤯"
    }

    function securityIsEnterprise(sec) {
        const s = String(sec || "")
        return s.includes("802.1X") || s.includes("Enterprise")
    }

    function securityLabel(sec, isEnt) {
        if (isEnt) return "Enterprise"
        const s = String(sec || "").trim()
        if (s === "" || s === "--") return "Open"
        return "Secured"
    }

    Process {
        id: procStatus
        command: ["bash", "-c", `
            WIFI_STATE=$(nmcli -g WIFI radio 2>/dev/null || echo "unknown")
            echo "WIFI:$WIFI_STATE"
            
            # Check for wired connection first
            WIRED_ACTIVE=$(nmcli -g UUID,TYPE,STATE connection show --active 2>/dev/null | awk -F: '$2=="802-3-ethernet" && $3=="activated"{print $1; exit}')
            
            if [ -n "$WIRED_ACTIVE" ]; then
                echo "TYPE:wired"
                echo "UUID:$WIRED_ACTIVE"
                echo "STATE:activated"
                CONN_NAME=$(nmcli -g connection.id connection show uuid "$WIRED_ACTIVE" 2>/dev/null | head -n1)
                echo "CONN_NAME:$CONN_NAME"
                IP=$(ip -o route get 1.1.1.1 2>/dev/null | awk '{for(i=1;i<=NF;i++) if($i=="src"){print $(i+1); exit}}')
                echo "IP:$IP"
                exit 0
            fi
            
            if [ "$WIFI_STATE" != "enabled" ]; then
                exit 0
            fi
            
            ACTIVE=$(nmcli -g UUID,TYPE,STATE connection show --active 2>/dev/null | awk -F: '$2=="802-11-wireless" && $3=="activated"{print $1; exit}')
            
            if [ -z "$ACTIVE" ]; then
                ACTIVATING=$(nmcli -g UUID,TYPE,STATE connection show --active 2>/dev/null | awk -F: '$2=="802-11-wireless" && $3=="activating"{print $1; exit}')
                if [ -n "$ACTIVATING" ]; then
                    echo "TYPE:wifi"
                    echo "UUID:$ACTIVATING"
                    echo "STATE:activating"
                    exit 0
                fi
                echo "TYPE:wifi"
                echo "STATE:disconnected"
                exit 0
            fi
            
            echo "TYPE:wifi"
            echo "UUID:$ACTIVE"
            echo "STATE:activated"
            
            SSID=$(nmcli -g 802-11-wireless.ssid connection show uuid "$ACTIVE" 2>/dev/null | head -n1)
            echo "SSID:$SSID"
            
            SIGNAL=$(nmcli -g IN-USE,SIGNAL dev wifi list 2>/dev/null | awk -F: '$1=="*"{print $2; exit}')
            echo "SIGNAL:$SIGNAL"
            
            IP=$(ip -o route get 1.1.1.1 2>/dev/null | awk '{for(i=1;i<=NF;i++) if($i=="src"){print $(i+1); exit}}')
            echo "IP:$IP"
        `]
        stdout: StdioCollector {
            onStreamFinished: {
                const lines = String(text || "").split(/\r?\n/)
                let wifi = "", connType = "", uuid = "", state = "", ssid = "", signal = "", ip = "", connName = ""
                
                for (let line of lines) {
                    const parts = line.trim().split(":")
                    if (parts.length < 2) continue
                    const key = parts[0]
                    const val = parts.slice(1).join(":")
                    
                    if (key === "WIFI") wifi = val
                    else if (key === "TYPE") connType = val
                    else if (key === "UUID") uuid = val
                    else if (key === "STATE") state = val
                    else if (key === "SSID") ssid = val
                    else if (key === "SIGNAL") signal = val
                    else if (key === "IP") ip = val
                    else if (key === "CONN_NAME") connName = val
                }
                
                wifiEnabled = (wifi === "enabled")
                isWired = (connType === "wired")
                
                activeConnectionUuid = uuid
                
                if (isWired) {
                    if (state === "activated") {
                        currentSsid = connName || "Wired Connection"
                        currentIp = ip
                        currentSignalVal = 0
                    } else {
                        currentSsid = "Disconnected"
                        currentIp = ""
                        currentSignalVal = 0
                    }
                    return
                }
                
                if (!wifiEnabled) {
                    currentSsid = "WiFi Off"
                    currentIp = ""
                    currentSignalVal = 0
                    activeConnectionUuid = ""
                    return
                }
                
                if (state === "activated") {
                    currentSsid = ssid || "Connected"
                    const sig = parseInt(signal, 10)
                    currentSignalVal = isFinite(sig) ? sig : 0
                    currentIp = ip
                } else if (state === "activating") {
                    currentSsid = "Connecting…"
                    currentIp = ""
                    currentSignalVal = 0
                } else {
                    currentSsid = "Disconnected"
                    currentIp = ""
                    currentSignalVal = 0
                }
            }
        }
    }

    function refreshStatus() {
        procStatus.running = true
    }

    ListModel { id: savedModel }
    property var savedBySsid: ({})
    property var savedByUuid: ({})

    function markSavedFlags() {
        const updates = []
        for (let i = 0; i < networkModel.count; i++) {
            const item = networkModel.get(i)
            const ss = item.ssid
            const wasSaved = item.isSaved
            const nowSaved = (savedBySsid[ss] !== undefined)
            
            if (wasSaved !== nowSaved) {
                updates.push({index: i, value: nowSaved})
            }
        }
        
        for (let u of updates) {
            networkModel.setProperty(u.index, "isSaved", u.value)
        }
    }

    Process {
        id: procSaved
        command: ["bash", "-c", `
            nmcli -t -f UUID,TYPE connection show 2>/dev/null \
            | awk -F: '$2=="802-11-wireless"{print $1}' \
            | while IFS= read -r uuid; do
                mapfile -t vals < <(nmcli -g 802-11-wireless.ssid,connection.id connection show uuid "$uuid" 2>/dev/null)

                ssid="\${vals[0]}"
                name="\${vals[1]}"

                [ -z "$name" ] && name="$ssid"
                [ -z "$ssid" ] && ssid="$name"
                [ -z "$ssid" ] && continue

                printf '%s\\t%s\\t%s\\n' "$uuid" "$ssid" "$name"
            done
        `]
        stdout: StdioCollector {
            onStreamFinished: {
                savedModel.clear()
                savedBySsid = ({})
                savedByUuid = ({})

                const lines = String(text || "").split(/\r?\n/)
                for (let line of lines) {
                    if (!line.trim()) continue
                    const parts = line.split("\t")
                    if (parts.length < 3) continue

                    const uuid = parts[0].trim()
                    const ssid = parts[1].trim()
                    const name = parts[2].trim()

                    if (!uuid || !ssid) continue

                    if (savedBySsid[ssid] === undefined) {
                        savedModel.append({ ssid, name, uuid })
                        savedBySsid[ssid] = { uuid, name }
                    }
                    savedByUuid[uuid] = { ssid, name }
                }

                markSavedFlags()
            }
        }
    }

    function refreshSaved() { 
        procSaved.running = true 
    }

    // Networks model
    ListModel { id: networkModel }
    property var ssidMap: ({})
    property var ssidBestSignal: ({})

    function upsertNetwork(ssid, bssid, sec, sig) {
        if (!ssid || ssid.length === 0) return
        if (!bssid || bssid.length === 0) return
        
        const ent = securityIsEnterprise(sec)
        const isSaved = (savedBySsid[ssid] !== undefined)

        if (ssidBestSignal[ssid] === undefined || sig > ssidBestSignal[ssid]) {
            ssidBestSignal[ssid] = sig
        }

        if (ssidMap[ssid] !== undefined) {
            const idx = ssidMap[ssid]
            if (idx < networkModel.count) {
                const current = networkModel.get(idx)
                if (sig > current.strength) {
                    networkModel.setProperty(idx, "bssid", bssid)
                    networkModel.setProperty(idx, "security", sec || "")
                    networkModel.setProperty(idx, "strength", sig)
                    networkModel.setProperty(idx, "isEnterprise", ent)
                    networkModel.setProperty(idx, "isSaved", isSaved)
                }
            }
            return
        }

        networkModel.append({
            ssid: ssid,
            bssid: bssid,
            security: sec || "",
            strength: sig,
            isEnterprise: ent,
            isSaved: isSaved
        })
        
        ssidMap[ssid] = networkModel.count - 1
    }

    function parseScanOutput(raw) {
        const lines = String(raw || "").split(/\r?\n/)
        for (let line of lines) {
            line = line.trim()
            if (!line) continue

            const safeLine = line.replace(/\\:/g, "___COLON___")
            const parts = safeLine.split(":")
            if (parts.length < 4) continue

            const bssid = parts[0].replace(/___COLON___/g, ":")
            const ssid = parts[1].replace(/___COLON___/g, ":")
            const sec = parts[2].replace(/___COLON___/g, ":")
            const sigStr = parts[3]

            let sig = parseInt(sigStr, 10)
            if (!isFinite(sig)) sig = 0
            if (!ssid || ssid.length === 0) continue

            upsertNetwork(ssid, bssid, sec, sig)
        }
    }

    Process {
        id: scanner
        command: ["bash", "-c", "nmcli -g BSSID,SSID,SECURITY,SIGNAL dev wifi list --rescan yes 2>/dev/null"]
        stdout: StdioCollector {
            onStreamFinished: {
                scanRunning = false
                processWatchdog.stop()
                parseScanOutput(text || "")
                
                refreshSaved()

                if (networkModel.count === 0 && savedModel.count === 0) {
                    setStatus("No networks found", true)
                } else {
                    setStatus("Networks updated", false)
                }
            }
        }
        onExited: {
            if (exitCode !== 0 && scanRunning) {
                scanRunning = false
                processWatchdog.stop()
                setStatus("Scan failed", true)
            }
        }
    }

    function performScan() {
        if (!wifiEnabled) {
            setStatus("WiFi is off", true)
            return
        }
        
        scanRunning = true
        processWatchdog.restart()
        scanner.running = true
    }

    Process {
        id: runner
        stdout: StdioCollector {
            onStreamFinished: {
                isBusy = false
                processWatchdog.stop()
                const out = String(text || "")
                const ok = out.includes("__EXIT:0")

                if (ok) {
                    setStatus("Connected", false)
                    errorBox.visible = false
                    viewStack.currentIndex = 0
                    statusRefreshDelay.restart()
                    return
                }

                if (out.includes("Secrets were required") || out.includes("No suitable secrets")) {
                    errorBox.visible = false
                    setStatus("Password required", true)
                    targetSsid = pendingSavedSsid
                    viewStack.currentIndex = 1
                    Qt.callLater(() => {
                        if (targetIsEnterprise) userField.forceActiveFocus()
                        else passField.forceActiveFocus()
                    })
                    return
                }

                const lines = out.trim().split(/\r?\n/)
                const tail = lines.slice(Math.max(0, lines.length - 10)).join("\n")
                errorBox.text = tail.length ? tail : "Connection failed. Check credentials and try again."
                errorBox.visible = true
                setStatus("Connection failed", true)
                refreshStatus()
                refreshSaved()
            }
        }
        onExited: {
            if (exitCode !== 0 && isBusy) {
                isBusy = false
                processWatchdog.stop()
                setStatus("Connection failed", true)
            }
        }
    }

    Timer {
        id: statusRefreshDelay
        interval: 1500
        repeat: false
        onTriggered: {
            refreshStatus()
            refreshSaved()
        }
    }

    function runWithExit(cmdString) {
        if (isBusy) return
        isBusy = true
        processWatchdog.restart()
        errorBox.visible = false
        setStatus("Working…", false)
        runner.command = ["bash", "-c", cmdString + " 2>&1; rc=$?; echo __EXIT:$rc"]
        runner.running = true
    }

    function connectSaved(uuid, ssid) {
        pendingSavedUuid = uuid
        pendingSavedSsid = ssid
        
        if (!uuid || uuid === "") {
            setStatus("Invalid connection", true)
            return
        }
        
        runWithExit("nmcli -w 15 connection up uuid " + shellQuote(uuid))
    }

    function setSavedPskAndConnect(uuid, password) {
        runWithExit(
            "nmcli connection modify uuid " + shellQuote(uuid) +
            " 802-11-wireless-security.key-mgmt wpa-psk " +
            " 802-11-wireless-security.psk " + shellQuote(password) + " && " +
            "nmcli -w 15 connection up uuid " + shellQuote(uuid)
        )
    }

    function connectNew(ssid, password, username, isEnterprise) {
        if (savedBySsid[ssid] !== undefined) {
            connectSaved(savedBySsid[ssid].uuid, ssid)
            return
        }

        let cmd = ""
        if (isEnterprise) {
            cmd =
                "nmcli -w 20 dev wifi connect " + shellQuote(ssid) +
                " password " + shellQuote(password) +
                " wifi-sec.key-mgmt wpa-eap " +
                " 802-1x.eap peap " +
                " 802-1x.phase2-auth mschapv2 " +
                " 802-1x.identity " + shellQuote(username)
        } else {
            cmd = "nmcli -w 20 dev wifi connect " + shellQuote(ssid)
            if (password && password.trim().length > 0)
                cmd += " password " + shellQuote(password)
        }

        pendingSavedUuid = ""
        pendingSavedSsid = ssid

        runWithExit(cmd)
    }

    function toggleWifi() {
        if (isBusy) return
        runWithExit("nmcli radio wifi " + (wifiEnabled ? "off" : "on"))
    }

    function disconnectNetwork() {
        if (isBusy) return
        if (!activeConnectionUuid || activeConnectionUuid === "") {
            setStatus("No active connection", true)
            return
        }
        runWithExit("nmcli connection down uuid " + shellQuote(activeConnectionUuid))
    }

    function startScanToggle() {
        if (isBusy) return

        if (!wifiEnabled) {
            setStatus("WiFi is off", true)
            return
        }

        if (!isExpanded) {
            isExpanded = true
            viewStack.currentIndex = 0
            networkModel.clear()
            ssidMap = ({})
            ssidBestSignal = ({})
            
            refreshSaved()
            scanDebounce.restart()
        } else {
            isExpanded = false
            scanRunning = false
            scanDebounce.stop()
        }
    }

    function rescanNow() {
        if (isBusy || !wifiEnabled) return
        networkModel.clear()
        ssidMap = ({})
        ssidBestSignal = ({})
        scanDebounce.restart()
    }

    function openAdvancedEditor() {
        Quickshell.execDetached(["nm-connection-editor"])
    }

    onActiveChanged: {
        if (active) {
            refreshStatus()
            Qt.callLater(() => {
                refreshSaved()
            })
        } else {
            viewStack.currentIndex = 0
            targetSsid = ""
            enteredPass = ""
            enteredUser = ""
        }
    }

    ColumnLayout {
        id: contentLayout
        spacing: 8
        Layout.fillWidth: true
        z: 1

        RowLayout {
            Layout.fillWidth: true
            Text {
                text: "Internet"
                color: root.textPrimary
                font.family: Theme.textFont
                font.pixelSize: 16
                font.weight: Font.Bold
                Layout.fillWidth: true
            }

            Rectangle {
                width: 46; height: 24
                radius: 12
                color: (wifiEnabled || isWired) ? Qt.rgba(accent.r, accent.g, accent.b, 0.95) : bgItemHover
                opacity: isBusy ? 0.6 : 1.0

                Rectangle {
                    width: 18; height: 18
                    radius: 9
                    color: root.theme ? root.theme.bgCard : Theme.bgCard
                    anchors.verticalCenter: parent.verticalCenter
                    x: (wifiEnabled || isWired) ? parent.width - width - 3 : 3
                }

                MouseArea {
                    anchors.fill: parent
                    cursorShape: isBusy ? Qt.ArrowCursor : Qt.PointingHandCursor
                    enabled: !isBusy && !isWired
                    onClicked: {
                        if (!isWired) toggleWifi()
                    }
                }
            }
        }

        Rectangle {
            Layout.fillWidth: true
            height: 76
            radius: 14
            color: bgItemHover

            RowLayout {
                anchors.fill: parent
                anchors.margins: 14
                spacing: 12

                Rectangle {
                    width: 44; height: 44
                    radius: 14
                    color: "transparent"
                    Text {
                        anchors.centerIn: parent
                        text: {
                            if (isWired) return "󰈀"
                            if (wifiEnabled) return getSignalIcon(currentSignalVal)
                            return "󰤮"
                        }
                        font.pixelSize: 22
                        font.family: Theme.iconFont
                        color: (isWired || wifiEnabled) ? accent : textSecondary
                    }
                }

                ColumnLayout {
                    Layout.fillWidth: true
                    spacing: 2
                    Text {
                        text: currentSsid
                        color: root.textPrimary
                        font.family: Theme.textFont
                        font.pixelSize: 14
                        font.weight: Font.Bold
                        elide: Text.ElideRight
                        Layout.fillWidth: true
                    }
                    Text {
                        text: {
                            if (currentIp && currentIp.length > 0) return currentIp
                            if (isWired) return "No IP address"
                            if (wifiEnabled) return "No IP address"
                            return "WiFi disabled"
                        }
                        color: root.textSecondary
                        font.family: Theme.textFont
                        font.pixelSize: 12
                        elide: Text.ElideRight
                        Layout.fillWidth: true
                    }
                }

                Rectangle {
                    visible: (wifiEnabled || isWired) && activeConnectionUuid !== ""
                    width: 36; height: 36
                    radius: 12
                    color: discMouse.containsMouse ? Qt.rgba(accentRed.r, accentRed.g, accentRed.b, 0.12) : "transparent"
                    opacity: isBusy ? 0.6 : 1.0

                    Text {
                        anchors.centerIn: parent
                        text: "󰅙"
                        font.family: Theme.iconFont
                        color: accentRed
                        font.pixelSize: 16
                    }

                    MouseArea {
                        id: discMouse
                        anchors.fill: parent
                        hoverEnabled: true
                        cursorShape: isBusy ? Qt.ArrowCursor : Qt.PointingHandCursor
                        enabled: !isBusy
                        onClicked: disconnectNetwork()
                    }
                }
            }
        }

        WifiMenuButton {
            Layout.alignment: Qt.AlignRight
            Layout.preferredWidth: 100
            Layout.preferredHeight: 26
            text: isExpanded ? "Close" : "Networks"
            icon: isExpanded ? "" : ""
            kind: "ghost"
            disabled: isBusy
            theme: root.theme
            onClicked: startScanToggle()
        }

        Text {
            visible: statusLine.length > 0
            text: statusLine
            color: statusColor
            font.family: Theme.textFont
            font.pixelSize: 11
        }

        TextArea {
            id: errorBox
            visible: false
            readOnly: true
            wrapMode: Text.Wrap
            Layout.fillWidth: true
            Layout.preferredHeight: Math.min(contentHeight + 20, 120)
            font.family: Theme.textFont
            font.pixelSize: 11
            color: accentRed
            background: Rectangle {
                radius: 12
                color: Qt.rgba(accentRed.r, accentRed.g, accentRed.b, 0.12)
            }
        }

        Rectangle {
            Layout.fillWidth: true
            height: 1
            visible: isExpanded
            opacity: 0.3
            color: textSecondary
        }

        Item {
            Layout.fillWidth: true
            implicitHeight: isExpanded ? viewStack.children[viewStack.currentIndex].implicitHeight : 0
            visible: isExpanded
            opacity: isExpanded ? 1 : 0
            clip: true
            
            StackLayout {
                id: viewStack
                anchors.top: parent.top
                anchors.left: parent.left
                anchors.right: parent.right
                currentIndex: 0

                // 0 = lists
                ColumnLayout {
                    spacing: 10
                    
                    Item {
                        Layout.fillWidth: true
                        Layout.preferredHeight: 86
                        visible: !scanRunning && savedModel.count === 0 && networkModel.count === 0

                        ColumnLayout {
                            anchors.centerIn: parent
                            spacing: 6

                            Text {
                                text: "No networks found"
                                color: root.textPrimary
                                font.family: Theme.textFont
                                font.pixelSize: 13
                                font.weight: Font.Bold
                            }

                            Text {
                                text: "Try rescan."
                                color: root.textSecondary
                                font.family: Theme.textFont
                                font.pixelSize: 11
                            }

                            WifiMenuButton {
                                height: 34
                                text: "Rescan"
                                icon: "󰑓"
                                kind: "outline"
                                disabled: scanRunning || isBusy
                                theme: root.theme
                                onClicked: rescanNow()
                            }
                        }
                    }

                    RowLayout {
                        Layout.fillWidth: true
                        visible: savedModel.count > 0
                        Text {
                            text: "Saved"
                            color: root.textSecondary
                            font.family: Theme.textFont
                            font.pixelSize: 12
                            font.weight: Font.Bold
                            Layout.fillWidth: true
                        }
                        BusyIndicator { 
                            running: scanRunning
                            visible: scanRunning
                            layer.enabled: true
                            layer.effect: ColorOverlay {
                                color: accent
                            }
                        }
                    }

                    ListView {
                        Layout.fillWidth: true
                        Layout.preferredHeight: Math.min(210, Math.max(0, savedModel.count * 48))
                        visible: savedModel.count > 0
                        clip: true
                        model: savedModel
                        spacing: 6
                        ScrollBar.vertical: ScrollBar { active: true; width: 4 }
                        delegate: SavedNetworkItem {
                            isBusy: root.isBusy
                            accent: root.accent
                            accentBlue: root.accentBlue
                            textPrimary: root.textPrimary
                            textSecondary: root.textSecondary
                            onConnectRequested: (uuid, ssid) => root.connectSaved(uuid, ssid)
                        }
                    }

                    Text {
                        text: "Available"
                        color: root.textSecondary
                        font.family: Theme.textFont
                        font.pixelSize: 12
                        font.weight: Font.Bold
                        visible: networkModel.count > 0
                    }

                    ListView {
                        Layout.fillWidth: true
                        Layout.preferredHeight: Math.min(280, Math.max(0, networkModel.count * 48))
                        visible: networkModel.count > 0
                        clip: true
                        model: networkModel
                        spacing: 6
                        ScrollBar.vertical: ScrollBar { active: true; width: 4 }
                        delegate: NetworkItem {
                            isBusy: root.isBusy
                            accent: root.accent
                            accentBlue: root.accentBlue
                            textPrimary: root.textPrimary
                            textSecondary: root.textSecondary
                            savedBySsid: root.savedBySsid
                            pendingSavedUuid: root.pendingSavedUuid
                            pendingSavedSsid: root.pendingSavedSsid
                            targetSsid: root.targetSsid
                            targetIsEnterprise: root.targetIsEnterprise
                            enteredUser: root.enteredUser
                            enteredPass: root.enteredPass
                            onConnectSavedRequested: (uuid, ssid) => root.connectSaved(uuid, ssid)
                            onConnectNewRequested: (ssid, password, username, isEnterprise) => root.connectNew(ssid, password, username, isEnterprise)
                            onShowPasswordForm: (ssid, isEnterprise) => {
                                root.targetSsid = ssid
                                root.targetIsEnterprise = isEnterprise
                                root.enteredUser = ""
                                root.enteredPass = ""
                                root.pendingSavedUuid = ""
                                root.pendingSavedSsid = ssid
                                viewStack.currentIndex = 1
                                Qt.callLater(() => {
                                    if (targetIsEnterprise) userField.forceActiveFocus()
                                    else passField.forceActiveFocus()
                                })
                            }
                        }
                    }

                    WifiMenuButton {
                        Layout.fillWidth: true
                        height: 38
                        text: "Open Advanced Settings"
                        icon: "󰒓"
                        kind: "ghost"
                        disabled: isBusy
                        theme: root.theme
                        onClicked: openAdvancedEditor()
                    }
                }

                // 1 = password
                ColumnLayout {
                    spacing: 12

                    Text {
                        text: targetIsEnterprise ? ("Log in to " + targetSsid) : ("Password for " + targetSsid)
                        color: root.textPrimary
                        font.family: Theme.textFont
                        font.pixelSize: 14
                        font.weight: Font.Bold
                        Layout.fillWidth: true
                        elide: Text.ElideRight
                    }

                    WifiPillField {
                        id: userField
                        visible: targetIsEnterprise
                        Layout.fillWidth: true
                        placeholder: "Username"
                        text: enteredUser
                        enabled: !isBusy
                        theme: root.theme
                        onTextChanged: enteredUser = text
                        onAccepted: passField.forceActiveFocus()
                    }

                    WifiPillField {
                        id: passField
                        Layout.fillWidth: true
                        placeholder: "Password"
                        echoMode: TextInput.Password
                        text: enteredPass
                        enabled: !isBusy
                        theme: root.theme
                        onTextChanged: enteredPass = text
                        onAccepted: {
                            if (pendingSavedUuid !== "") setSavedPskAndConnect(pendingSavedUuid, enteredPass)
                            else connectNew(targetSsid, enteredPass, enteredUser, targetIsEnterprise)
                        }
                    }

                    RowLayout {
                        spacing: 10
                        Layout.fillWidth: true

                        WifiMenuButton {
                            Layout.fillWidth: true
                            height: 40
                            text: "Back"
                            icon: "󰁍"
                            kind: "outline"
                            disabled: isBusy
                            theme: root.theme
                            onClicked: viewStack.currentIndex = 0
                        }

                        WifiMenuButton {
                            Layout.fillWidth: true
                            height: 40
                            text: isBusy ? "Connecting…" : "Connect"
                            btnColor: accent
                            textColor: root.theme ? root.theme.bgCard : Theme.bgCard
                            icon: "󱄙"
                            kind: "primary"
                            disabled: isBusy
                            theme: root.theme
                            onClicked: {
                                if (pendingSavedUuid !== "") setSavedPskAndConnect(pendingSavedUuid, enteredPass)
                                else connectNew(targetSsid, enteredPass, enteredUser, targetIsEnterprise)
                            }
                        }
                    }

                    WifiMenuButton {
                        Layout.fillWidth: true
                        height: 38
                        text: "Open Advanced Settings"
                        icon: "󰒓"
                        kind: "ghost"
                        disabled: isBusy
                        theme: root.theme
                        onClicked: openAdvancedEditor()
                    }
                }
            }
        }
    }
}

