import QtQuick
import QtQuick.Layouts
import "../../../config/theme.js" as Theme

Rectangle {
    id: field
    property alias text: input.text
    property string placeholder: ""
    property int echoMode: TextInput.Normal
    property bool enabled: true
    property QtObject theme: null
    signal accepted()

    Layout.preferredHeight: 42
    radius: 999
    color: Theme.bgItemHover
    opacity: enabled ? 1.0 : 0.6
    clip: true

    TextInput {
        id: input
        anchors.fill: parent
        anchors.leftMargin: 14
        anchors.rightMargin: 14

        enabled: field.enabled
        color: Theme.fgMain
        font.family: Theme.textFont
        font.pixelSize: 13
        echoMode: field.echoMode
        verticalAlignment: TextInput.AlignVCenter
        selectByMouse: true
        activeFocusOnTab: true
        Keys.onReturnPressed: field.accepted()
    }

    Text {
        anchors.left: parent.left
        anchors.leftMargin: 14
        anchors.verticalCenter: parent.verticalCenter
        text: field.placeholder
        color: Theme.fgMuted
        font.family: Theme.textFont
        font.pixelSize: 13
        visible: input.text.length === 0 && !input.activeFocus
    }

    MouseArea {
        anchors.fill: parent
        enabled: field.enabled
        cursorShape: Qt.IBeamCursor
        onClicked: input.forceActiveFocus()
    }
}

