import QtQuick
import Quickshell


QtObject {
    function sh(cmd) {
        return ["bash", "-c", cmd];
    }

    function det(cmd) {
        Quickshell.execDetached(sh(cmd));
    }

    function exec(cmd) {
        return Quickshell.exec(sh(cmd));
    }
}

