import QtQuick
import QtQuick.Layouts
import Quickshell
import "../../ui" as Lib
import "../../widgets" as Widgets
import "../../../config/theme.js" as Theme
import "../../../utils" as Utils

Lib.Card {
  id: root
  signal closeRequested()
  signal batteryToggleRequested()
  signal wifiMenuRequested()
  property bool active: true

  Utils.CommandUtils {
      id: cmdUtils
  }

  // --- WIFI / WIRED ---
  Widgets.CommandPoll {
    id: wiredConnection
    running: root.active && root.visible
    interval: 3000
    command: cmdUtils.sh("UUID=$(nmcli -g UUID,TYPE,STATE connection show --active 2>/dev/null | awk -F: '$2==\"802-3-ethernet\" && $3==\"activated\"{print $1; exit}'); if [ -n \"$UUID\" ]; then nmcli -g connection.id connection show uuid \"$UUID\" 2>/dev/null | head -n1; fi")
    parse: function(o) {
      var name = String(o).trim()
      return name || ""
    }
  }

  Widgets.CommandPoll {
    id: wifiOn
    running: root.active && root.visible
    interval: 2500
    command: cmdUtils.sh("nmcli -t -f WIFI g 2>/dev/null | head -n1 || true")
    parse: function(o) { return String(o).trim() === "enabled" }
  }

  Widgets.CommandPoll {
    id: wifiSSID
    running: root.active && root.visible
    interval: 5000
    command: cmdUtils.sh("nmcli -t -f ACTIVE,SSID dev wifi 2>/dev/null | awk -F: '$1==\"yes\"{print $2; exit}' || true")
    parse: function(o) {
      var s = String(o).trim() || "WiFi"
      return s.length > 9 ? s.slice(0, 9) : s
    }
  }

  readonly property bool isWired: String(wiredConnection.value || "").trim().length > 0

  function toggleWifi() {
    var next = !Boolean(wifiOn.value)
    cmdUtils.det("nmcli radio wifi " + (next ? "on" : "off"))
  }

  // --- BLUETOOTH ---
  Widgets.CommandPoll {
    id: btOn
    running: root.active && root.visible
    interval: 3000
    command: cmdUtils.sh("bluetoothctl show 2>/dev/null | awk -F': ' '/Powered:/{print $2; exit}' || true")
    parse: function(o) { return String(o).trim() === "yes" }
  }

  Widgets.CommandPoll {
    id: btDev
    running: root.active && root.visible
    interval: 3500
    command: cmdUtils.sh("bluetoothctl devices Connected 2>/dev/null | head -n1 | cut -d' ' -f3- || true")
    parse: function(o) {
      var d = String(o).trim()
      if (d.length > 0) return d.length > 9 ? d.slice(0, 9) : d
      if (btOn.value === false) return "Off"
      return "On"
    }
  }

  function toggleBt() {
    var next = !Boolean(btOn.value)
    cmdUtils.det("bluetoothctl power " + (next ? "on" : "off"))
  }

  // --- VOLUME / BRIGHTNESS ---
  Widgets.CommandPoll {
    id: volPoll
    running: root.active && root.visible
    interval: 1200
    command: cmdUtils.sh("pactl get-sink-volume @DEFAULT_SINK@ 2>/dev/null | grep -Po '\\d+(?=%)' | head -n1")
    parse: function(o) {
      var n = parseInt(String(o).trim())
      return isFinite(n) ? n : 0
    }
    onUpdated: if (!volS.pressed) volS.value = value
  }

  Widgets.CommandPoll {
    id: briPoll
    running: root.active && root.visible
    interval: 1500
    command: cmdUtils.sh("brightnessctl -m 2>/dev/null | cut -d, -f4 | tr -d '% ' || true")
    parse: function(o) {
      var n = Number(String(o).trim())
      return isFinite(n) ? n : 50
    }
    onUpdated: if (!briS.pressed) briS.value = value
  }

  // --- SURFACE PROFILE ---
  property string localPerfState: "balanced"

  Widgets.CommandPoll {
    id: perfPoll
    running: root.active && root.visible
    interval: 5000
    command: cmdUtils.sh("sudo surface profile get 2>/dev/null || echo 'balanced'")
    parse: function(o) {
      var val = String(o).trim().toLowerCase()
      root.localPerfState = val
      return val
    }
  }

  function cyclePerf() {
    var current = root.localPerfState
    var next = "balanced"
    if (current.includes("low")) next = "balanced"
    else if (current === "balanced") next = "balanced-performance"
    else if (current.includes("balanced-performance")) next = "performance"
    else if (current.includes("performance")) next = "low-power"
    root.localPerfState = next
    cmdUtils.det("sudo surface profile set " + next)
  }

  function getPerfIcon() {
    var s = root.localPerfState
    if (s.includes("low")) return ""
    if (s === "balanced") return "󰾅"
    if (s.includes("balanced-performance")) return ""
    if (s.includes("performance")) return ""
    return "󰾅"
  }

  function getPerfLabel() {
    var s = root.localPerfState
    if (s.includes("low")) return "Saver"
    if (s === "balanced") return "Normal"
    if (s.includes("balanced-performance")) return "Optimized"
    if (s.includes("performance")) return "Perf"
    return "Normal"
  }

  function isPerfActive() {
    var s = root.localPerfState
    return (s.includes("low") || s === "balanced")
  }

  function getPerfColor() {
    var s = root.localPerfState
    if (s.includes("balanced-performance")) return "#dbbc7f"
    if (s.includes("performance")) return Theme.accentRed
    return (root.theme ? root.theme.textPrimary : Theme.fgMain)
  }

  // --- DND ---
  property bool dnd: false

  Widgets.CommandPoll {
    id: dndPoll
    running: root.active && root.visible
    interval: 4000
    command: cmdUtils.sh("makoctl mode 2>/dev/null || true")
    parse: function(o) { return String(o).includes("do-not-disturb") }
    onUpdated: root.dnd = value
  }

  function toggleDnd() {
    var next = !root.dnd
    root.dnd = next
    cmdUtils.det("makoctl mode " + (next ? "-a" : "-r") + " do-not-disturb")
  }

  // --- UI ---
  ColumnLayout {
    spacing: 12
    width: parent.width

    RowLayout {
      spacing: 12
      Layout.fillWidth: true

      Widgets.ExpressiveButton {
        theme: root.theme
        icon: root.isWired ? "󰈀" : "󰤨"
        label: root.isWired ? (String(wiredConnection.value || "Wired").length > 9 ? String(wiredConnection.value).slice(0, 9) : String(wiredConnection.value || "Wired")) : String(wifiSSID.value || "WiFi")
        active: root.isWired || Boolean(wifiOn.value)
        onClicked: {
            root.wifiMenuRequested()
        }
        onRightClicked: {
            if (!root.isWired) toggleWifi()
        }
        fixX: -10
      }

      Widgets.ExpressiveButton {
        theme: root.theme
        icon: "󰂯"
        label: String(btDev.value || "Off")
        active: Boolean(btOn.value)
        onClicked: toggleBt()
        onRightClicked: {
            root.closeRequested()
            cmdUtils.det("blueman-manager >/dev/null 2>&1 &")
        }
        fixX: -5
      }

      Widgets.ExpressiveButton {
        theme: root.theme
        icon: root.getPerfIcon()
        label: root.getPerfLabel()
        active: root.isPerfActive()
        customIconColor: root.getPerfColor()
        hasCustomColor: !root.isPerfActive()
        onClicked: root.cyclePerf()
        onRightClicked: root.batteryToggleRequested()
        fixX: -2
      }

      Widgets.ExpressiveButton {
        theme: root.theme
        icon: root.dnd ? "󰂛" : "󰂚"
        label: root.dnd ? "Silent" : "Notify"
        active: root.dnd
        onClicked: toggleDnd()
        fixX: -3
      }
    }

  ColumnLayout {
    spacing: 8
    Layout.fillWidth: true

      Widgets.ExpressiveSlider {
        theme: root.theme
        id: briS
        icon: "󰃟"
        from: 0; to: 100
        value: 50
        Layout.fillWidth: true
        accentColor: (root.theme && root.theme.isDarkMode !== undefined && !root.theme.isDarkMode)
            ? root.theme.accentSlider
            : "#83C092"
        onUserChanged: cmdUtils.det("brightnessctl set " + Math.round(value) + "%")
      }

      Widgets.ExpressiveSlider {
        theme: root.theme
        id: volS
        icon: "󰕾"
        from: 0; to: 100
        value: 0
        Layout.fillWidth: true
        accentColor: (root.theme && root.theme.isDarkMode !== undefined && !root.theme.isDarkMode)
            ? root.theme.accentSlider
            : "#83C092"
        onUserChanged: cmdUtils.det("pactl set-sink-volume @DEFAULT_SINK@ " + Math.round(value) + "%")
      } 
    }
  }
}
