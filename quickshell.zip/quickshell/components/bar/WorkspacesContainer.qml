import QtQuick
import QtQuick.Layouts
import Qt5Compat.GraphicalEffects
import "../../config/theme.js" as Theme
import "." as Cache

Rectangle {
    id: root

    property int activeWsId: 1
    property var wsMap: []
    property bool isDarkMode: true
    property int workspaceCount: {
        let max = Math.max(activeWsId, wsMap.length);
        return Math.max(2, max);
    }

    signal workspaceClicked(int wsId)

    height: 30
    width: wsRow.width + 8
    radius: 20
    color: palette.bg
    clip: true

    property int hoveredId: 0
    property var hoveredItem: (hoveredId > 0) ? wsRepeater.itemAt(hoveredId - 1) : null
    property int pressedId: 0
    property var pressedItem: (pressedId > 0) ? wsRepeater.itemAt(pressedId - 1) : null

    QtObject {
        id: palette
        property color bg: Theme.bg
        property color activePill: Theme.accent
        property color textPrimary: Theme.textPrimary
        property color accent: Theme.accent
        property color hoverPillG0: Qt.rgba(167 / 255, 192 / 255, 128 / 255, 0.15)
        property color hoverPillG1: Qt.rgba(230 / 255, 255 / 255, 200 / 255, 0.25)
        property color hoverPillG2: Qt.rgba(167 / 255, 192 / 255, 128 / 255, 0.15)
    }

    // ACTIVE PILL
    Rectangle {
        id: activePill
        property int currentId: root.activeWsId
        property var targetItem: wsRepeater.itemAt(currentId - 1)
        x: targetItem ? (wsRow.x + targetItem.x) : 0
        width: targetItem ? targetItem.width : 0
        height: 22
        anchors.verticalCenter: parent.verticalCenter
        radius: 20
        color: palette.activePill
        Behavior on x {
            NumberAnimation {
                duration: 260
                easing.type: Easing.OutCubic
            }
        }
        Behavior on width {
            NumberAnimation {
                duration: 240
                easing.type: Easing.OutCubic
            }
        }
    }

    // HOVER PILL
    Item {
        id: hoverPillLayer
        anchors.fill: parent
        visible: root.hoveredId > 0 && root.hoveredId !== root.activeWsId
        opacity: visible ? 1 : 0
        Behavior on opacity {
            NumberAnimation {
                duration: 140
                easing.type: Easing.OutCubic
            }
        }
    }

    Item {
        id: pressPillLayer
        anchors.fill: parent
        visible: root.pressedId > 0
        opacity: visible ? 1 : 0
        Behavior on opacity {
            NumberAnimation {
                duration: 90
                easing.type: Easing.OutCubic
            }
        }

        Rectangle {
            property var t: root.pressedItem
            x: t ? (wsRow.x + t.x) : 0
            width: t ? t.width : 0
            height: 25
            anchors.verticalCenter: parent.verticalCenter
            radius: 20
            color: Qt.rgba(palette.textPrimary.r, palette.textPrimary.g, palette.textPrimary.b, 1)
            opacity: 0.10
            Behavior on x {
                NumberAnimation {
                    duration: 120
                    easing.type: Easing.OutCubic
                }
            }
            Behavior on width {
                NumberAnimation {
                    duration: 120
                    easing.type: Easing.OutCubic
                }
            }
        }
    }

    Row {
        id: wsRow
        anchors.centerIn: parent
        spacing: 3
        Repeater {
            id: wsRepeater
            model: root.workspaceCount
            Item {
                id: wsDelegate
                property int wsId: index + 1
                property bool isActive: root.activeWsId === wsId
                property var wsWindows: root.wsMap[wsId - 1] ?? []
                property int winCount: wsWindows.length
                property bool hasWindows: winCount > 0
                property bool isUrgent: wsWindows.some(tl => tl.urgent)

                width: hasWindows ? (winCount * 24) : 26
                height: 34

                HoverHandler {
                    id: wsHover
                    onHoveredChanged: {
                        if (hovered)
                            root.hoveredId = wsId;
                        else if (root.hoveredId === wsId)
                            root.hoveredId = 0;
                    }
                }

                y: wsPress.pressed ? 1 : ((!isActive && wsHover.hovered) ? -2 : 0)
                scale: (wsPress.pressed ? 0.96 : 1.0) * ((!isActive && wsHover.hovered) ? 1.10 : 1.0)
                Behavior on y {
                    NumberAnimation {
                        duration: 180
                        easing.type: Easing.OutCubic
                    }
                }
                Behavior on scale {
                    NumberAnimation {
                        duration: 220
                        easing.type: Easing.OutBack
                        easing.overshoot: 1.08
                    }
                }

                Text {
                    anchors.centerIn: parent
                    visible: !wsDelegate.hasWindows
                    text: "•"
                    font.family: Theme.iconFont
                    font.pixelSize: 14
                    lineHeight: 0.8
                    verticalAlignment: Text.AlignVCenter
                    Behavior on color {
                        ColorAnimation {
                            duration: 140
                        }
                    }
                    color: isActive ? "#2d353b" : (wsHover.hovered ? "#f2f2f2" : "#d5c9b2")
                }

                Row {
                    anchors.centerIn: parent
                    spacing: 0
                    visible: wsDelegate.hasWindows
                    Repeater {
                        model: wsDelegate.wsWindows
                        Item {
                            width: 22
                            height: 22

                            property string safeClass: {
                                const o = modelData?.lastIpcObject;
                                var c = o?.class ?? "";
                                if (!c)
                                    c = o?.initialClass ?? "";
                                if (!c)
                                    c = o?.initialTitle ?? "";
                                if (!c)
                                    c = modelData?.title ?? "";
                                return String(c);
                            }

                            QtObject {
                                id: flashColor
                                property color val: "#d5c9b2"
                                SequentialAnimation on val {
                                    running: modelData.urgent
                                    loops: Animation.Infinite
                                    ColorAnimation {
                                        to: "#e67e80"
                                        duration: 200
                                    }
                                    ColorAnimation {
                                        to: "#dbbc7f"
                                        duration: 200
                                    }
                                }
                            }

                            Item {
                                anchors.fill: parent

                                IconImage {
                                    id: windowIcon
                                    anchors.centerIn: parent
                                    icon: parent.parent.safeClass
                                    iconSize: 20
                                    scale: (wsDelegate.isActive && wsHover.hovered) ? 1.25 : 1.0

                                    Behavior on scale {
                                        NumberAnimation {
                                            duration: 200
                                            easing.type: Easing.OutBack
                                            easing.overshoot: 1.5
                                        }
                                    }
                                    opacity: (wsDelegate.isActive || modelData.urgent || wsHover.hovered) ? 1.0 : 0.8
                                    Behavior on opacity {
                                        NumberAnimation {
                                            duration: 140
                                        }
                                    }
                                }

                                // Fallback to text icon if image fails or not loaded yet
                                Text {
                                    anchors.centerIn: parent
                                    visible: windowIcon.status === Image.Error || windowIcon.source === "" || windowIcon.iconPath === ""
                                    text: "-"
                                    font.family: Theme.iconFont
                                    font.pixelSize: 18
                                    lineHeight: 0.8
                                    verticalAlignment: Text.AlignVCenter
                                    Behavior on color {
                                        enabled: !modelData.urgent
                                        ColorAnimation {
                                            duration: 140
                                        }
                                    }
                                    scale: (wsDelegate.isActive && wsHover.hovered) ? 1.25 : 1.0
                                    Behavior on scale {
                                        NumberAnimation {
                                            duration: 200
                                            easing.type: Easing.OutBack
                                            easing.overshoot: 1.5
                                        }
                                    }
                                    color: wsDelegate.isActive ? "#2d353b" : (modelData.urgent ? flashColor.val : (wsHover.hovered ? "#f2f2f2" : "#d5c9b2"))
                                }
                            }
                        }
                    }
                }

                MouseArea {
                    id: wsPress
                    anchors.fill: parent
                    hoverEnabled: true
                    onPressed: root.pressedId = wsId
                    onReleased: if (root.pressedId === wsId)
                        root.pressedId = 0
                    onCanceled: if (root.pressedId === wsId)
                        root.pressedId = 0
                    onClicked: root.workspaceClicked(wsId)
                }
            }
        }
    }
}
