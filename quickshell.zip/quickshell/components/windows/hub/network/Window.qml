import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Io
import Quickshell.Wayland
import "../../../../config/theme.js" as Theme
import "../../../ui" as Lib
import "../../../../config/config.js" as Config
import "../../../../utils" as Utils
import "../../../../services" as Services 

PanelWindow {
    id: win
    color: "transparent"
    anchors {
        top: true
        bottom: true
        left: true
        right: true
    }


    // Hides window borders when the hub is open
    function setBordersHidden(hidden) {
        systemService.setBordersHidden(hidden);
    }

    function closeAll() {
        if (header)
            header.expanded = false;
        win.visible = false;
    }
    onVisibleChanged: {
        setBordersHidden(visible);
        if (!visible) {
            win.batteryCardActive = false;
            win.wifiCardActive = false;
            if (header)
                header.expanded = false;
        } else {
            root.forceActiveFocus();
        }
    }

    property int barStrip: 2

    Lib.ThemeEngine {
        id: theme
    }

    Services.SystemService {
        id: systemService
    }

    margins {
        top: barStrip
    }
    aboveWindows: true
    WlrLayershell.layer: WlrLayer.Overlay
    focusable: visible
    WlrLayershell.keyboardFocus: visible ? WlrKeyboardFocus.OnDemand : WlrKeyboardFocus.None

    property string profileName: Config.PROFILE_NAME
    property string profileImage: Config.PROFILE_IMG
    property bool batteryCardActive: false
    property bool wifiCardActive: false
    property int topGap: 8
    property int leftGap: 10
    property int panelW: 320

    function executeAction(action) {
        systemService.executeAction(action);
        closeAll();
    }

    Item {
        id: root
        anchors.fill: parent
        focus: true

        Keys.onEscapePressed: closeAll()
        Keys.onPressed: event => {
            // Press 'P' to toggle the power menu
            if (event.key === Qt.Key_P) {
                if (header) {
                    header.expanded = !header.expanded;
                    event.accepted = true;
                }
            }
        }

        // click outside closes
        MouseArea {
            anchors.fill: parent
            acceptedButtons: Qt.AllButtons
            preventStealing: true
            onPressed: closeAll()
        }

        Rectangle {
            id: panel
            width: win.panelW
            height: Math.ceil(layout.implicitHeight + 24)
            radius: Theme.radiusOuter
            color: Theme.bg

            anchors {
                left: parent.left
                top: parent.top
                leftMargin: win.leftGap
                topMargin: win.topGap
            }

            MouseArea {
                anchors.fill: parent
                acceptedButtons: Qt.AllButtons
                preventStealing: true
                onPressed: mouse => mouse.accepted = true
            }

            ColumnLayout {
                id: layout
                anchors.fill: parent
                anchors.margins: 12
                spacing: Theme.gapCard

                WifiCard {
                    id: wifi
                    Layout.fillWidth: true
                    active: win.wifiCardActive
                    theme: theme
                }
            }
        }
    }
}
