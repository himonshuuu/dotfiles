import QtQuick
import QtQuick.Layouts
import QtQuick.Controls
import Quickshell.Wayland
import "../../config/theme.js" as Theme
import "../windows/network" as Network

Item {
    id: root
    Layout.preferredWidth: parent.width / 3
    Layout.preferredHeight: 30

    Network.Window {
        id: networkWindow
        visible: root.menuOpen
    }

    property bool menuOpen: false

    Rectangle {
        anchors.fill: parent
        radius: height / 2
        color: Theme.bgItem
        border.width: 0
        opacity: mouseArea.containsMouse ? 0.9 : 1.0
        Behavior on opacity {
            NumberAnimation {
                duration: 120
            }
        }
    }

    MouseArea {
        id: mouseArea
        anchors.fill: parent
        cursorShape: Qt.PointingHandCursor
        onClicked: {
            networkWindow.visible = true;
        }
    }

    RowLayout {
        anchors.centerIn: parent
        spacing: 6
        Layout.preferredWidth: 60
        Text {
            text: ""
            color: Theme.textPrimary
        }
        Text {
            text: "WiFi"
            color: Theme.textPrimary
        }
    }
}
