import QtQuick
import QtQuick.Layouts
import "../../../config/theme.js" as Theme

Rectangle {
    required property string ssid
    required property string bssid
    required property string security
    required property int strength
    required property bool isEnterprise
    required property bool isSaved
    required property bool isBusy
    required property color accent
    required property color accentBlue
    required property color textPrimary
    required property color textSecondary
    
    required property var savedBySsid
    required property string pendingSavedUuid
    required property string pendingSavedSsid
    required property string targetSsid
    required property bool targetIsEnterprise
    required property string enteredUser
    required property string enteredPass
    
    signal connectSavedRequested(string uuid, string ssid)
    signal connectNewRequested(string ssid, string password, string username, bool isEnterprise)
    signal showPasswordForm(string ssid, bool isEnterprise)
    
    width: ListView.view ? ListView.view.width : 0
    height: 54
    radius: 12
    color: nm.containsMouse ? Qt.rgba(accentBlue.r, accentBlue.g, accentBlue.b, 0.10) : "transparent"
    opacity: isBusy ? 0.6 : 1.0

    function getSignalIcon(strength) {
        if (strength > 80) return "󰤨"
        if (strength > 60) return "󰤥"
        if (strength > 40) return "󰤢"
        if (strength > 20) return "󰤟"
        return "󰤯"
    }

    function securityLabel(sec, isEnt) {
        if (isEnt) return "Enterprise"
        const s = String(sec || "").trim()
        if (s === "" || s === "--") return "Open"
        return "Secured"
    }

    RowLayout {
        anchors.fill: parent
        anchors.margins: 10
        spacing: 10

        Text { 
            text: getSignalIcon(strength)
            font.family: Theme.iconFont
            font.pixelSize: 14
            color: accent
        }

        ColumnLayout {
            Layout.fillWidth: true
            spacing: 0
            Text {
                text: ssid || ""
                color: textPrimary
                font.family: Theme.textFont
                font.pixelSize: 13
                font.weight: Font.Bold
                Layout.fillWidth: true
                elide: Text.ElideRight
            }
            Text {
                text: isSaved ? "Saved" : securityLabel(security, isEnterprise)
                color: textSecondary
                font.family: Theme.textFont
                font.pixelSize: 10
            }
        }

        Text {
            text: {
                const sec = security || ""
                return (isSaved || (sec.trim() !== "" && sec !== "--")) ? "󰌾" : "󰦝"
            }
            font.family: Theme.iconFont
            font.pixelSize: 12
            color: textSecondary
        }
    }

    MouseArea {
        id: nm
        anchors.fill: parent
        hoverEnabled: true
        cursorShape: isBusy ? Qt.ArrowCursor : Qt.PointingHandCursor
        enabled: !isBusy
        onClicked: {
            if (isSaved) {
                let uuid = savedBySsid[ssid] ? savedBySsid[ssid].uuid : ""
                if (uuid) {
                    connectSavedRequested(uuid, ssid)
                }
                return
            }

            const sec = String(security || "").trim()
            const isOpen = (sec === "" || sec === "--")

            if (isOpen) {
                connectNewRequested(ssid, "", "", isEnterprise)
                return
            }

            showPasswordForm(ssid, isEnterprise)
        }
    }
}

