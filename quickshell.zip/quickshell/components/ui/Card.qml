import QtQuick
import QtQuick.Layouts
import "../../config/theme.js" as Theme

Rectangle {
    id: root
    property QtObject theme: null
    property int pad: 6
    property int gap: 10

    // Background
    color: root.theme ? root.theme.bgCard : Theme.bgCard
    radius: Theme.radiusOuter

    // Hover
    HoverHandler {
        id: hoverHandler
    }

    // Lift
    scale: hoverHandler.hovered ? 1.005 : 1.0
    Behavior on scale {
        NumberAnimation {
            duration: 300
            easing.type: Easing.OutQuint
        }
    }


    // Content
    default property alias content: container.data

    implicitHeight: container.implicitHeight + (pad * 2)
    implicitWidth: container.implicitWidth + (pad * 2)

    ColumnLayout {
        id: container
        anchors.top: parent.top
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.margins: root.pad
        spacing: root.gap
    }
}
