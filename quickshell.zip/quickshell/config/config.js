.pragma library

// User profile configuration
var PROFILE_IMG = "/home/human/.config/quickshell/config/962f63c35f08997001b6644cb45fc9c1.png"
var PROFILE_NAME = "human"

// Layout configuration
var TOP_GAP = 50
var RIGHT_GAP = 10
var PANEL_W = 34
var PANEL_H = 600

var WEATHER_SCRIPT_PATH = ".config/ags/script/weather.sh"
var SNAP_CMD = "command -v grimblast >/dev/null && grimblast --notify copysave area || true"
var SNAP_SCRIPT_PATH = ".config/hypr/screenshots/captureArea.sh"
