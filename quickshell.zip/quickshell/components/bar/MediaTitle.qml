import QtQuick
import QtQuick.Layouts
import QtQuick.Controls
import Qt5Compat.GraphicalEffects
import Quickshell.Io
import Quickshell
import Quickshell.Services.Mpris

import "../ui" as Lib
import "../widgets" as Widgets
import "../../config/theme.js" as Theme
import "../windows/media" as Media

Rectangle {
    id: root

    property int baseHeight: 30
    property real animH: root.hasPlayer ? root.baseHeight : 0

    signal clicked

    implicitHeight: animH
    implicitWidth: layout.implicitWidth + 10

    Behavior on animH {
        NumberAnimation {
            duration: 200
            easing.type: Easing.OutCubic
        }
    }

    visible: animH > 1
    opacity: root.hasPlayer ? 1.0 : 0.0
    Behavior on opacity {
        NumberAnimation { duration: 150 }
    }

    radius: height / 2
    color: Theme.bg
    clip: true

    Media.Window {
        id: mediaWindow
        visible: false
    }

  
    property var players: Mpris.players.values
    property MprisPlayer player: null

    function pickPlayer() {
        var ps = root.players || [];
        if (ps.length === 0) {
            root.player = null;
            return;
        }

        for (var i = 0; i < ps.length; i++)
            if (ps[i] && ps[i].isPlaying) {
                root.player = ps[i];
                return;
            }

        for (var j = 0; j < ps.length; j++)
            if (ps[j] && ps[j].playbackState === MprisPlaybackState.Paused) {
                root.player = ps[j];
                return;
            }

        root.player = ps[0];
    }

    Timer {
        interval: 1500
        repeat: true
        running: true
        triggeredOnStart: true
        onTriggered: root.pickPlayer()
    }

    property bool hasPlayer: root.player !== null
    property bool isPlaying: root.player ? root.player.isPlaying : false

    property string title: (root.player && root.player.trackTitle) ? root.player.trackTitle : "Not Playing"
    property string artist: (root.player && root.player.trackArtist) ? root.player.trackArtist : "System Audio"
    property string artUrl: (root.player && root.player.trackArtUrl) ? root.player.trackArtUrl : ""
    property color accentColor: Theme.accent

    RowLayout {
        id: layout
        anchors.centerIn: parent
        spacing: 6

        Widgets.MediaButton {
            icon: "󰒮"
            size: 26
            tint: root.accentColor
            hoverable: true
            clickable: true
            onClicked: {
                if (root.player && root.player.canGoPrevious)
                    root.player.previous();
            }
        }

        Image {
            source: root.artUrl
            width: 24
            height: 24
            fillMode: Image.PreserveAspectCrop
            cache: true
            asynchronous: true
            sourceSize.width: 24
            sourceSize.height: 24

            layer.enabled: root.artUrl !== ""
            layer.smooth: true
            layer.effect: OpacityMask {
                maskSource: Rectangle {
                    width: 24
                    height: 24
                    radius: 6
                }
            }
        }

        Text {
            text: root.title + " <font color='" + Theme.textSecondary + "'>- " + root.artist + "</font>"
            font.family: Theme.textFont
            font.pixelSize: 11
            color: Theme.fgMain
            textFormat: Text.RichText
            verticalAlignment: Text.AlignVCenter
            elide: Text.ElideRight
        }

        Widgets.MediaButton {
            icon: "󰒭"
            size: 26
            tint: root.accentColor
            hoverable: true
            clickable: true
            onClicked: {
                if (root.player && root.player.canGoNext)
                    root.player.next();
            }
        }
    }

    MouseArea {
        anchors.centerIn: parent
        width: parent.width - 65
        height: parent.height
        acceptedButtons: Qt.LeftButton | Qt.RightButton
        hoverEnabled: true
        propagateComposedEvents: false
     
        onClicked: function(mouse) {
            if (mouse.button === Qt.LeftButton) {
                mouse.accepted = true;
                mediaWindow.visible = !mediaWindow.visible;
            } else if (mouse.button === Qt.RightButton) {
                if (root.player) {
                    if (root.player.isPlaying && root.player.canPause) {
                        root.player.pause();
                    } else if (!root.player.isPlaying && root.player.canPlay) {
                        root.player.play();
                    }
                }
            }
        }
        preventStealing: true
    }
}
