import QtQuick
import Quickshell
import Quickshell.Io

Item {
    id: root

    property string icon: ""
    property int iconSize: 18
    width: iconSize
    height: iconSize

    property var iconMap: []

    FileView {
        id: iconMapFile
        path: Quickshell.env("HOME") + "/.config/quickshell/config/icon_map.json"
        onTextChanged: {
            try {
                root.iconMap = JSON.parse(text());
            } catch (e) {
                console.warn("Failed to parse icon_map.json:", e);
            }
        }
    }

    function normalizeIconString(str) {
        if (!str)
            return "";
        var s = String(str);
        var i = s.lastIndexOf("/");
        if (i >= 0)
            s = s.substring(i + 1);
        i = s.indexOf("?");
        if (i >= 0)
            s = s.substring(0, i);
        s = s.replace(/\.(svg|png|xpm|desktop)$/i, "");
        return s.trim().toLowerCase();
    }

    function findIconPath(iconString) {
        var normName = normalizeIconString(iconString);
        if (root.iconMap && root.iconMap.length) {
            for (var i = 0; i < root.iconMap.length; ++i) {
                var entry = root.iconMap[i];
                var keywords = entry.keywords;
                for (var j = 0; j < keywords.length; ++j) {
                    var kwNorm = normalizeIconString(keywords[j]);
                    if (normName === kwNorm || normName === keywords[j].toLowerCase()) {
                        return entry.image;
                    }
                }
            }
        }
        return "";
    }

    property string iconPath: {
        if (!icon)
            return "";
        var path = findIconPath(icon);
        if (!path)
            return "";
        if (path.indexOf("/") === 0 || path.startsWith("file:") || path.startsWith("qrc:/") || path.startsWith("resource:")) {
            return path;
        }
        return path;
    }

    Image {
        id: img
        anchors.fill: parent
        source: iconPath
        fillMode: Image.PreserveAspectFit
        smooth: true
        visible: status === Image.Ready
    }
}
