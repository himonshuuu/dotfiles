import QtQuick
import QtQuick.Layouts
import "../../../config/theme.js" as Theme

Rectangle {
    id: btn
    property string text: ""
    property string icon: ""
    property string kind: "outline"
    property bool disabled: false
    property QtObject theme: null
    
    property color btnColor: Theme.accent
    property color textColor: (kind === "primary") ? (theme ? theme.bgCard : Theme.bgCard) : Theme.fgMain

    signal clicked()

    radius: 12
    implicitHeight: 40

    scale: pressed ? 0.95 : (hovered && !disabled ? 1.045 : 1.0)

    readonly property bool hovered: mouse.containsMouse
    readonly property bool pressed: mouse.pressed

    color: {
        if (kind === "primary") {
            if (disabled) return Qt.rgba(btnColor.r, btnColor.g, btnColor.b, 0.35)
            return hovered ? Qt.darker(btnColor, 1.1) : btnColor
        }
        if (kind === "ghost") return hovered ? Qt.rgba(Theme.accentBlue.r, Theme.accentBlue.g, Theme.accentBlue.b, 0.10) : "transparent"
        return hovered ? Qt.rgba(Theme.accentBlue.r, Theme.accentBlue.g, Theme.accentBlue.b, 0.10) : "transparent"
    }

    opacity: disabled ? 0.55 : 1.0
    
    RowLayout {
        anchors.centerIn: parent
        spacing: 8

        Text {
            visible: btn.icon.length > 0
            text: btn.icon
            font.family: Theme.iconFont
            font.pixelSize: 16
            color: btn.textColor
        }

        Text {
            text: btn.text
            color: btn.textColor
            font.family: Theme.textFont
            font.pixelSize: 13
            font.weight: Font.Bold
        }
    }

    MouseArea {
        id: mouse
        anchors.fill: parent
        hoverEnabled: true
        cursorShape: btn.disabled ? Qt.ArrowCursor : Qt.PointingHandCursor
        enabled: !btn.disabled
        onClicked: btn.clicked()
    }
}

