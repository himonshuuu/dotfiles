import QtQuick
import Quickshell.Hyprland

Item {
    id: root
    property var wsMap: []
    property bool pending: false

    visible: false

    function rebuild() {
        const m = [];
        const list = Hyprland.toplevels?.values ?? [];

        for (const tl of list) {
            const id = tl?.workspace?.id;
            if (!id)
                continue;
            if (!m[id - 1])
                m[id - 1] = [];

            m[id - 1].push(tl);
        }

        wsMap = m;
    }

    function scheduleRebuild() {
        if (pending)
            return;
        pending = true;
        Qt.callLater(() => {
            pending = false;
            rebuild();
        });
    }

    Component.onCompleted: rebuild()

    Timer {
        interval: 500
        running: true
        repeat: false
        onTriggered: root.rebuild()
    }

    Timer {
        interval: 2000
        running: true
        repeat: false
        onTriggered: root.rebuild()
    }

    Connections {
        target: Hyprland
        function onRawEvent(ev) {
            if (!ev || !ev.name)
                return;
            if (ev.name === "openwindow" || ev.name === "closewindow" || ev.name === "movewindowv2" || ev.name === "workspacev2" || ev.name === "activewindowv2" || ev.name === "urgent") {
                Hyprland.refreshToplevels();
                root.scheduleRebuild();
            }
        }
    }
}
