import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Io
import Quickshell.Wayland
import "../../../config/theme.js" as Theme
import "../../ui" as Lib
import "../../../config/config.js" as Config
import "../../../utils" as Utils
import "../../../services" as Services
import "." 

PanelWindow {
    id: win
    color: "transparent"
    anchors {
        top: true
        bottom: true
        left: true
        right: true
    }

    function setBordersHidden(hidden) {
        systemService.setBordersHidden(hidden);
    }

    function closeAll() {
        win.visible = false;
    }
    // onVisibleChanged: {
    //     setBordersHidden(visible);
    //     if (!visible) {
    //         win.batteryCardActive = false;
    //         win.wifiCardActive = false;
    //         if (header)
    //             header.expanded = false;
    //     } else {
    //         root.forceActiveFocus();
    //     }
    // }

    property int barStrip: 2

    Lib.ThemeEngine {
        id: theme
    }

    Services.SystemService {
        id: systemService
    }

    margins {
        top: barStrip
    }
    aboveWindows: true
    WlrLayershell.layer: WlrLayer.Overlay
    focusable: visible
    WlrLayershell.keyboardFocus: visible ? WlrKeyboardFocus.OnDemand : WlrKeyboardFocus.None

    property string profileName: Config.PROFILE_NAME
    property string profileImage: Config.PROFILE_IMG
    property int topGap: 8
    property int leftGap: 10
    property int panelW: 320

    function executeAction(action) {
        systemService.executeAction(action);
        closeAll();
    }

    Item {
        id: root
        anchors.fill: parent
        focus: true

        Keys.onEscapePressed: closeAll()
     
        MouseArea {
            anchors.fill: parent
            acceptedButtons: Qt.AllButtons
            preventStealing: true
            onPressed: closeAll()
        }

        Rectangle {
            id: panel
            width: win.panelW
            height: layout.implicitHeight
            radius: 100
            // color: Theme.bg

            anchors {
                right: parent.right
                top: parent.top
                rightMargin: win.rightGap
                topMargin: win.topGap
            }

            MouseArea {
                anchors.fill: parent
                acceptedButtons: Qt.AllButtons
                preventStealing: true
                onPressed: mouse => mouse.accepted = true
            }

            ColumnLayout {
                id: layout
                anchors.fill: parent
                anchors.margins: {
                    left: 0
                    right: 0
                    top: 0
                    bottom: 0
                }
                spacing:0

                Sliders {
                    id: buttons
                    Layout.fillWidth: true
                    active: win.visible
                    onCloseRequested: closeAll()
                }
            }
        }
    }
}
