import QtQuick
import Quickshell.Io
import "../components/ui" as Lib
import "../components/widgets" as Widgets

/**
 * Battery service - provides battery information polling
 * Can be reused across components
 */
Item {
    id: root

    property int capacity: 0
    property string status: ""
    property bool plugged: false
    property bool isCharging: plugged || status === "Charging" || status === "Full"

    property int pollInterval: {
        if (status === "Discharging" && capacity <= 20)
            return 2000; // Poll more frequently when battery is low
        return 6000; // Normal polling interval
    }

    Widgets.CommandPoll {
        id: powerPoll
        interval: root.pollInterval
        command: ["bash", "-lc", `
            cap=$(cat /sys/class/power_supply/BAT*/capacity 2>/dev/null | head -n1)
            status=$(cat /sys/class/power_supply/BAT*/status 2>/dev/null | head -n1)
            ac=$(cat /sys/class/power_supply/AC*/online /sys/class/power_supply/ADP*/online 2>/dev/null | head -n1)
            echo "$cap|$status|$ac"
        `]
        parse: function (o) {
            var s = String(o ?? "").trim();
            var p = s.split("|");
            root.capacity = Number(p[0]) || 0;
            root.status = (p[1] || "").trim();
            root.plugged = (String(p[2] || "").trim() === "1");
            return {
                cap: root.capacity,
                status: root.status,
                ac: root.plugged ? "1" : "0"
            };
        }
    }
}

