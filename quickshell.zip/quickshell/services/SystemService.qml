import QtQuick
import Quickshell
import "../utils" as Utils


Item {
    id: root

    Utils.CommandUtils {
        id: cmdUtils
    }

    function executeAction(action) {
        var cmd = "";
        switch (action) {
        case "shutdown":
            cmd = "systemctl poweroff";
            break;
        case "reboot":
            cmd = "systemctl reboot";
            break;
        case "hibernate":
            cmd = "systemctl hibernate";
            break;
        case "suspend":
            cmd = "mpc -q pause; amixer set Master mute; systemctl suspend";
            break;
        case "logout":
            cmd = "hyprctl dispatch exit";
            break;
        case "lock":
            cmd = "if command -v hyprlock >/dev/null; then hyprlock; " + 
                  "elif command -v betterlockscreen >/dev/null; then betterlockscreen -l; " + 
                  "elif command -v i3lock >/dev/null; then i3lock; fi";
            break;
        }

        if (cmd !== "")
            cmdUtils.det(cmd);
    }

    function setBordersHidden(hidden) {
        cmdUtils.det("hyprctl keyword general:border_size 0");
    }
}

